// add this line including the hash: 
// #include "config.h" 
// config.h
#ifndef CONFIG_H
#define CONFIG_H

// Wifi network credentials
const char* ssid = "ChrisnAimee.com";
const char* password = "carbondell";

#endif
